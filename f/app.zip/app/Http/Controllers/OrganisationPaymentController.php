<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OrganisationPaymentController extends Controller
{
    //
}
